its simple calculator which adds substracts multiplys and divides to values
